package com.extreamvomit.androidcoolmouth;

/**
 * Created by vesp on 15/12/07.
 */


        import android.app.PendingIntent;
        import android.app.Service;
        import android.appwidget.AppWidgetManager;
        import android.content.ComponentName;
        import android.content.Intent;
        import android.media.AudioManager;
        import android.media.SoundPool;
        import android.os.IBinder;
        import android.util.Log;
        import android.widget.RemoteViews;

public class ServiceSample extends Service {
    private final String BUTTON_CLICK_ACTION = "BUTTON_CLICK_ACTION";
    private final String TAG = "Test_ServiceLog"; // デバッグ用

    //効果音用
    SoundPool sp;
    int sound_id;

    @Override
    public void onCreate() {
        // 効果音用
        sp = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        sound_id = sp.load(getApplicationContext(), R.raw.se_maoudamashii_system46, 1 );
    }

    @Override
    public void onStart(Intent intent, int startId) {
        Log.d(TAG, "onStart");
        super.onStart(intent, startId);

        // ボタンが押された時に発行されるインテントを準備する
        
        Intent buttonIntent = new Intent();
        buttonIntent.setAction(BUTTON_CLICK_ACTION);
        PendingIntent pendingIntent = PendingIntent.getService(this, appWidgetId, buttonIntent, 0); //Serviceへインテントを投げる


        Log.d(TAG, "pendingIntent準備完了");
        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.main);
        remoteViews.setOnClickPendingIntent(R.id.button, pendingIntent); // WidgetButtonをIntent発行者とする、これで押した時に発行される
        Log.d(TAG, "remoteview(Widgetボタン)へセット完了、Intent発行？");

        // ボタンが押された時に発行されたインテントの場合は文字を変更する
        if (BUTTON_CLICK_ACTION.equals(intent.getAction())) {
            remoteViews.setTextViewText(R.id.text, "Push Button");
            sp.play(sound_id, 1.0F, 1.0F, 0, 0, 1.0F);
            Log.d(TAG, "BUTTON_CLICK_ACTION");
        }

        // AppWidgetの画面更新
        Log.d(TAG, "appWidgetManager起動");
        ComponentName thisWidget = new ComponentName(this, MyWidget.class);
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        manager.updateAppWidget(thisWidget, remoteViews);
        Log.d(TAG, "updateAppwidget終了");
    }

    // Bindは使わないのでNULLで返す
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}